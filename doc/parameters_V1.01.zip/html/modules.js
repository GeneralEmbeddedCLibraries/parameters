var modules =
[
    [ "PARARAMETERS_API", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i" ],
    [ "KERNEL_FUNCTIONS", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s" ],
    [ "PARAMETERS_API", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html", "group___p_a_r_a_m_e_t_e_r_s___a_p_i" ],
    [ "PAR_NVM", "group___p_a_r___n_v_m.html", "group___p_a_r___n_v_m" ],
    [ "KERNEL_PAR_NVM_FUNCTIONS", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s" ]
];