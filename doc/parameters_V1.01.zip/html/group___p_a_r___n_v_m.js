var group___p_a_r___n_v_m =
[
    [ "par_nvm_obj_t", "unionpar__nvm__obj__t.html", [
      [ "crc", "unionpar__nvm__obj__t.html#a1c23ccc4e89142ff960b93a753192c8b", null ],
      [ "field", "unionpar__nvm__obj__t.html#a667befbabada7cf179e6c83a001523de", null ],
      [ "id", "unionpar__nvm__obj__t.html#a3275bf94c941d35cd8bdd4c2584164e6", null ],
      [ "u", "unionpar__nvm__obj__t.html#a9dd7f332cb5c12f2b711a51e93f6e0e9", null ],
      [ "val", "unionpar__nvm__obj__t.html#a08bad3be0974890da4665565c78ab629", null ]
    ] ],
    [ "PAR_NVM_HEADER_ADDR_OFFSET", "group___p_a_r___n_v_m.html#ga4b4d57fbccb406d1bee8931994fa0fdc", null ],
    [ "PAR_NVM_PAR_OBJ_ADDR_OFFSET", "group___p_a_r___n_v_m.html#ga79907180202591cc34c7edda8d3fd893", null ],
    [ "PAR_NVM_SIGNATURE", "group___p_a_r___n_v_m.html#ga2791cc1ac37d89baee8a4dca922a04cb", null ],
    [ "PAR_NVM_SIGNATURE_ADDR_OFFSET", "group___p_a_r___n_v_m.html#gaca8166ada33c649ecd44d29e0d4e99a2", null ],
    [ "PAR_NVM_TABLE_ID_ADDR_OFFSET", "group___p_a_r___n_v_m.html#ga86261b3d384b708726bc2be91cd9713f", null ],
    [ "par_nvm_init", "group___p_a_r___n_v_m.html#ga6edd0d2ef60beb2a0c755547fa1872d1", null ],
    [ "par_nvm_write", "group___p_a_r___n_v_m.html#ga87355a65f364a4f9ec16fd889dc79c09", null ],
    [ "par_nvm_write_all", "group___p_a_r___n_v_m.html#ga600da4f6f0d52db3726a739429758f2e", null ]
];