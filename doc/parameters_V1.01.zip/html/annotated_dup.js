var annotated_dup =
[
    [ "par_cfg_t", "structpar__cfg__t.html", "structpar__cfg__t" ],
    [ "par_nvm_obj_t", "unionpar__nvm__obj__t.html", "unionpar__nvm__obj__t" ],
    [ "par_type_t", "unionpar__type__t.html", "unionpar__type__t" ]
];