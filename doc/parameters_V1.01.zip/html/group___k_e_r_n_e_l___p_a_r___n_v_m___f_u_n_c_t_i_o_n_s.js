var group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s =
[
    [ "par_nvm_calc_crc", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga2856d3948a259a7df8523ba1d56ff522", null ],
    [ "par_nvm_calc_num_of_per_par", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gaefd87ae69043c36d1f6e56e4d5bf6871", null ],
    [ "par_nvm_check_signature", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gab0474db0f7c97aac1cd134f37c95f8ba", null ],
    [ "par_nvm_check_table_id", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga79ba2b84b682dca1e1f5d0c555961850", null ],
    [ "par_nvm_erase_signature", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga433daa0a61ef86a873cf59013db58795", null ],
    [ "par_nvm_load_all", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gaf583ee60410611e376d4f6ea2f965508", null ],
    [ "par_nvm_read", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga2f9291af109aeaedbdb4b45cfeb515ae", null ],
    [ "par_nvm_read_header", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga40422c99d26211538fe4ee0be74a7be0", null ],
    [ "par_nvm_write_header", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gab2f8b0a78aab12f5b6412728a8726337", null ],
    [ "par_nvm_write_signature", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gab974ab946c1c795b9dd17d6e9930ccd2", null ],
    [ "par_nvm_write_table_id", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga9f37c39bdb17485a99b650ceac595897", null ]
];