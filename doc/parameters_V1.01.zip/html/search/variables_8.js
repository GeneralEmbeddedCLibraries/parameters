var searchData=
[
  ['persistant_170',['persistant',['../structpar__cfg__t.html#ad16904007491d68783d41ae4061aa945',1,'par_cfg_t']]]
];
