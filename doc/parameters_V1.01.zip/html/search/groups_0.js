var searchData=
[
  ['kernel_5ffunctions_196',['KERNEL_FUNCTIONS',['../group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html',1,'']]],
  ['kernel_5fpar_5fnvm_5ffunctions_197',['KERNEL_PAR_NVM_FUNCTIONS',['../group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html',1,'']]]
];
