var par_8h =
[
    [ "PAR_VER_DEVELOP", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaa5485965497c82d2f4d96594f428e73e", null ],
    [ "PAR_VER_MAJOR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gabfaddaf7ed5b92603b09ecad3728f88c", null ],
    [ "PAR_VER_MINOR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac3aa69f2555a9482d9f1e98e40187bac", null ],
    [ "par_io_acess_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gae8a938ba864297131896bfd747fc58c6", [
      [ "ePAR_ACCESS_RO", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggae8a938ba864297131896bfd747fc58c6aad898fd22be1a0c92ba81d9d412e3cc4", null ],
      [ "ePAR_ACCESS_RW", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggae8a938ba864297131896bfd747fc58c6af9a726767be255277823ad8a6c35f168", null ]
    ] ],
    [ "par_status_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga8b35ff6218581a8480bf2505e92c8bee", [
      [ "ePAR_OK", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0dbbe4c419686d60f42d0091fa6250cb", null ],
      [ "ePAR_ERROR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea859f819b82c26caa15144c73f6cd2d1d", null ],
      [ "ePAR_ERROR_INIT", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0a1d9fd2e31c2b3ecebd97f11b74e8e5", null ],
      [ "ePAR_ERROR_NVM", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beeafe5546b977d62a3934198fa15e28a5e0", null ],
      [ "ePAR_ERROR_CRC", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beeaff8022c03d2385f7bf4a287b35820d4b", null ],
      [ "ePAR_WARN_SET_TO_DEF", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea24388e3e3d2a51e8a2c86b51913080f2", null ],
      [ "ePAR_WARN_NVM_REWRITTEN", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea9abe24a140ee3f0c7b8a551f0eef0b35", null ],
      [ "ePAR_WARN_NO_PERSISTANT", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0576f783184ad8ac417a35aa3a8de2f7", null ]
    ] ],
    [ "par_type_list_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaa8d3468b379578b8357e4a9228348a64", [
      [ "ePAR_TYPE_U8", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a7465c58517f316c5f601aa6c687f9010", null ],
      [ "ePAR_TYPE_U16", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a7420e84aaa274ca10b18233ad3c1c4b2", null ],
      [ "ePAR_TYPE_U32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a0a47bc1d5e7c161d0955d474e50cf125", null ],
      [ "ePAR_TYPE_I8", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64aaf858711d1f92fa4d7594ced76d76bb4", null ],
      [ "ePAR_TYPE_I16", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a85705aaff1589f10d8b2526caed8ca40", null ],
      [ "ePAR_TYPE_I32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a741a6d24395ebed5fa8c222c1f7990dd", null ],
      [ "ePAR_TYPE_F32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64ac2b04414530ac596d50477af1022e7aa", null ],
      [ "ePAR_TYPE_NUM_OF", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a3fc3d7e1e31f523dc32b6b2010342aca", null ]
    ] ],
    [ "par_get", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gae2c6df3597d5618e92ce757fb393c9c7", null ],
    [ "par_get_config", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaf03f137bc8a20ab1751ee8b401b10b58", null ],
    [ "par_get_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9153055e6d3c6843313e84cad4281ba4", null ],
    [ "par_get_num_by_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga13ddbc714c148dfd78c168dc1dafe8be", null ],
    [ "par_get_type_size", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga3c2ece40717a85f283c68ed70db77e85", null ],
    [ "par_init", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga1a7fd1f42cf5df77ede707a7f6fad15a", null ],
    [ "par_is_init", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac8a591704d9f39b565162fce4a629014", null ],
    [ "par_save", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac08b41ec43a0d147548ee3926a47cca0", null ],
    [ "par_save_all", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga50b348a7b0b21b3897911d5d2bbbf8d1", null ],
    [ "par_save_by_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gade199dc627e67d4ccbff360c3489bf01", null ],
    [ "par_set", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gadf8554a43b483938b0e56c05b2eab505", null ],
    [ "par_set_all_to_default", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9e5828c96ccbacbd8e3fb24071f7de3c", null ],
    [ "par_set_to_default", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga40fd6543dd2a0ce372f26746cbcacac2", null ]
];