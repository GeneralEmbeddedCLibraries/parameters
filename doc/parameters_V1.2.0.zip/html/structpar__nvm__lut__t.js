var structpar__nvm__lut__t =
[
    [ "addr", "structpar__nvm__lut__t.html#a979830fab95ba158b83924d3da3bef56", null ],
    [ "id", "structpar__nvm__lut__t.html#a69ae7fb3de7977120dce375c9e211dd8", null ],
    [ "valid", "structpar__nvm__lut__t.html#ae8858c0ce010c9c35aef93e6d07f7a6e", null ]
];