var group___p_a_r_a_m_e_t_e_r_s___a_p_i =
[
    [ "par_type_t", "unionpar__type__t.html", [
      [ "f32", "unionpar__type__t.html#a05781c22a1ad3890083d44932df3d64f", null ],
      [ "i16", "unionpar__type__t.html#a1e54521e90a8af9e33238b480b0f5afe", null ],
      [ "i32", "unionpar__type__t.html#a726248fb3a9e73d0c5269777442b1e3b", null ],
      [ "i8", "unionpar__type__t.html#a1138fd5259ec70258f71f7a1d576f593", null ],
      [ "u16", "unionpar__type__t.html#aaed1c71f4b5c4feb27b088320e36962e", null ],
      [ "u32", "unionpar__type__t.html#a68f8c998e774592d22fdb2d0068251ed", null ],
      [ "u8", "unionpar__type__t.html#a66d7051a23d8c83e69af5f9ecb91692e", null ]
    ] ],
    [ "par_cfg_t", "structpar__cfg__t.html", [
      [ "access", "structpar__cfg__t.html#aab39c8a6ebc3b069fba8a8984a63484c", null ],
      [ "def", "structpar__cfg__t.html#a1bd59873dadfb10e0f23e2cd5db9c472", null ],
      [ "id", "structpar__cfg__t.html#aded4bf7e8ab9d3da3fe398718693a517", null ],
      [ "max", "structpar__cfg__t.html#a072e74e83ab1e7b9ec9cea7f731f3d60", null ],
      [ "min", "structpar__cfg__t.html#acd914431a675d89e6f60644b74e06591", null ],
      [ "name", "structpar__cfg__t.html#a9eae8067e34661996777165496d7899b", null ],
      [ "persistant", "structpar__cfg__t.html#ad16904007491d68783d41ae4061aa945", null ],
      [ "type", "structpar__cfg__t.html#a3527ab70f6bbbb3cca7e0ab6b159066b", null ],
      [ "unit", "structpar__cfg__t.html#a8d17be689a442ff6b5d103796f15e778", null ]
    ] ],
    [ "PAR_MAX_STRING_SIZE", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaedd09dbc07834919b98031f34ae99124", null ],
    [ "PAR_VER_DEVELOP", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaa5485965497c82d2f4d96594f428e73e", null ],
    [ "PAR_VER_MAJOR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gabfaddaf7ed5b92603b09ecad3728f88c", null ],
    [ "PAR_VER_MINOR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac3aa69f2555a9482d9f1e98e40187bac", null ],
    [ "par_io_acess_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gae8a938ba864297131896bfd747fc58c6", [
      [ "ePAR_ACCESS_RO", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggae8a938ba864297131896bfd747fc58c6aad898fd22be1a0c92ba81d9d412e3cc4", null ],
      [ "ePAR_ACCESS_RW", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggae8a938ba864297131896bfd747fc58c6af9a726767be255277823ad8a6c35f168", null ]
    ] ],
    [ "par_status_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga8b35ff6218581a8480bf2505e92c8bee", [
      [ "ePAR_OK", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0dbbe4c419686d60f42d0091fa6250cb", null ],
      [ "ePAR_ERROR", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea859f819b82c26caa15144c73f6cd2d1d", null ],
      [ "ePAR_ERROR_INIT", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0a1d9fd2e31c2b3ecebd97f11b74e8e5", null ],
      [ "ePAR_ERROR_NVM", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beeafe5546b977d62a3934198fa15e28a5e0", null ],
      [ "ePAR_ERROR_CRC", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beeaff8022c03d2385f7bf4a287b35820d4b", null ],
      [ "ePAR_WARN_SET_TO_DEF", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea24388e3e3d2a51e8a2c86b51913080f2", null ],
      [ "ePAR_WARN_NVM_REWRITTEN", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea9abe24a140ee3f0c7b8a551f0eef0b35", null ],
      [ "ePAR_WARN_NO_PERSISTANT", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gga8b35ff6218581a8480bf2505e92c8beea0576f783184ad8ac417a35aa3a8de2f7", null ]
    ] ],
    [ "par_type_list_t", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaa8d3468b379578b8357e4a9228348a64", [
      [ "ePAR_TYPE_U8", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a7465c58517f316c5f601aa6c687f9010", null ],
      [ "ePAR_TYPE_U16", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a7420e84aaa274ca10b18233ad3c1c4b2", null ],
      [ "ePAR_TYPE_U32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a0a47bc1d5e7c161d0955d474e50cf125", null ],
      [ "ePAR_TYPE_I8", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64aaf858711d1f92fa4d7594ced76d76bb4", null ],
      [ "ePAR_TYPE_I16", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a85705aaff1589f10d8b2526caed8ca40", null ],
      [ "ePAR_TYPE_I32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a741a6d24395ebed5fa8c222c1f7990dd", null ],
      [ "ePAR_TYPE_F32", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64ac2b04414530ac596d50477af1022e7aa", null ],
      [ "ePAR_TYPE_NUM_OF", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ggaa8d3468b379578b8357e4a9228348a64a3fc3d7e1e31f523dc32b6b2010342aca", null ]
    ] ],
    [ "par_get", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gae2c6df3597d5618e92ce757fb393c9c7", null ],
    [ "par_get_config", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gaf03f137bc8a20ab1751ee8b401b10b58", null ],
    [ "par_get_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9153055e6d3c6843313e84cad4281ba4", null ],
    [ "par_get_num_by_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga13ddbc714c148dfd78c168dc1dafe8be", null ],
    [ "par_get_type_size", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga3c2ece40717a85f283c68ed70db77e85", null ],
    [ "par_init", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga1a7fd1f42cf5df77ede707a7f6fad15a", null ],
    [ "par_is_init", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac8a591704d9f39b565162fce4a629014", null ],
    [ "par_save", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gac08b41ec43a0d147548ee3926a47cca0", null ],
    [ "par_save_all", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga50b348a7b0b21b3897911d5d2bbbf8d1", null ],
    [ "par_save_by_id", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gade199dc627e67d4ccbff360c3489bf01", null ],
    [ "par_set", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#gadf8554a43b483938b0e56c05b2eab505", null ],
    [ "par_set_all_to_default", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9e5828c96ccbacbd8e3fb24071f7de3c", null ],
    [ "par_set_to_default", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga40fd6543dd2a0ce372f26746cbcacac2", null ],
    [ "gb_is_init", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_par_table", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga59f4aa468dfc3681c215238c1a99c1f4", null ],
    [ "gpu8_par_value", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga6e720db045a3de7e212e6d13647833fa", null ],
    [ "gu32_par_addr_offset", "group___p_a_r_a_m_e_t_e_r_s___a_p_i.html#ga7631a8e1f644f28dc06d3ed9fa9cfde8", null ]
];