var structpar__cfg__t =
[
    [ "access", "structpar__cfg__t.html#aab39c8a6ebc3b069fba8a8984a63484c", null ],
    [ "def", "structpar__cfg__t.html#a1bd59873dadfb10e0f23e2cd5db9c472", null ],
    [ "id", "structpar__cfg__t.html#aded4bf7e8ab9d3da3fe398718693a517", null ],
    [ "max", "structpar__cfg__t.html#a072e74e83ab1e7b9ec9cea7f731f3d60", null ],
    [ "min", "structpar__cfg__t.html#acd914431a675d89e6f60644b74e06591", null ],
    [ "name", "structpar__cfg__t.html#a9eae8067e34661996777165496d7899b", null ],
    [ "persistant", "structpar__cfg__t.html#ad16904007491d68783d41ae4061aa945", null ],
    [ "type", "structpar__cfg__t.html#a3527ab70f6bbbb3cca7e0ab6b159066b", null ],
    [ "unit", "structpar__cfg__t.html#a8d17be689a442ff6b5d103796f15e778", null ]
];