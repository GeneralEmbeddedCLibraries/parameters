var group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s =
[
    [ "par_allocate_ram_space", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga11da4ecf3bce0f6af202ffc929bbd85d", null ],
    [ "par_calc_ram_usage", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga2beea3838274aedf6b5288bb5333ab05", null ],
    [ "par_check_table_validy", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga853d8e3f172b9d987e0cad483c303cef", null ],
    [ "par_set_f32", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga2867e3c071c2d150414fe17773b4f634", null ],
    [ "par_set_i16", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga6c26e2007e06731e956dc8c28eaab655", null ],
    [ "par_set_i32", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga6f3f3f1e18a6965a6828f1b527441886", null ],
    [ "par_set_i8", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga775ec909c81a646477e3787faa21385d", null ],
    [ "par_set_u16", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga8dc5d340431cdd1e4b20969eb280120e", null ],
    [ "par_set_u32", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#gad1b2b04499714e06c98667ca1aa19b0e", null ],
    [ "par_set_u8", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#gafa03b4ce2f99f8c1350ba8d9bda583b4", null ]
];