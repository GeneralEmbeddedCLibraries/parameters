var searchData=
[
  ['data_169',['data',['../structpar__nvm__data__obj__t.html#abfaf7d70159fabe8deced4d67390a83e',1,'par_nvm_data_obj_t']]],
  ['def_170',['def',['../structpar__cfg__t.html#a1bd59873dadfb10e0f23e2cd5db9c472',1,'par_cfg_t']]]
];
