var searchData=
[
  ['sign_186',['sign',['../structpar__nvm__head__obj__t.html#a52449a31e9d603cdb3df914434de0af4',1,'par_nvm_head_obj_t']]],
  ['size_187',['size',['../structpar__nvm__data__obj__t.html#a995fc8c3b36a66102e8c616a0e4e3d21',1,'par_nvm_data_obj_t']]]
];
