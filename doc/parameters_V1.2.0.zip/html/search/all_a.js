var searchData=
[
  ['obj_5fnb_38',['obj_nb',['../structpar__nvm__head__obj__t.html#a5a5eb845cfde6290fad9272683d9e25c',1,'par_nvm_head_obj_t']]]
];
