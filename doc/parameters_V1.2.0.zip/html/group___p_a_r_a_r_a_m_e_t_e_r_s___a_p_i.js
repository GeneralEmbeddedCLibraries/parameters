var group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i =
[
    [ "PAR_MAX_STRING_SIZE", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gaedd09dbc07834919b98031f34ae99124", null ],
    [ "par_get", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gae2c6df3597d5618e92ce757fb393c9c7", null ],
    [ "par_get_config", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gaf03f137bc8a20ab1751ee8b401b10b58", null ],
    [ "par_get_id", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9153055e6d3c6843313e84cad4281ba4", null ],
    [ "par_get_num_by_id", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga13ddbc714c148dfd78c168dc1dafe8be", null ],
    [ "par_get_type_size", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga3c2ece40717a85f283c68ed70db77e85", null ],
    [ "par_init", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga1a7fd1f42cf5df77ede707a7f6fad15a", null ],
    [ "par_is_init", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gac8a591704d9f39b565162fce4a629014", null ],
    [ "par_save", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gac08b41ec43a0d147548ee3926a47cca0", null ],
    [ "par_save_all", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga50b348a7b0b21b3897911d5d2bbbf8d1", null ],
    [ "par_save_by_id", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gade199dc627e67d4ccbff360c3489bf01", null ],
    [ "par_set", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#gadf8554a43b483938b0e56c05b2eab505", null ],
    [ "par_set_all_to_default", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga9e5828c96ccbacbd8e3fb24071f7de3c", null ],
    [ "par_set_to_default", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga40fd6543dd2a0ce372f26746cbcacac2", null ],
    [ "gb_is_init", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_par_table", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga59f4aa468dfc3681c215238c1a99c1f4", null ],
    [ "gpu8_par_value", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga6e720db045a3de7e212e6d13647833fa", null ],
    [ "gu32_par_addr_offset", "group___p_a_r_a_r_a_m_e_t_e_r_s___a_p_i.html#ga7631a8e1f644f28dc06d3ed9fa9cfde8", null ]
];