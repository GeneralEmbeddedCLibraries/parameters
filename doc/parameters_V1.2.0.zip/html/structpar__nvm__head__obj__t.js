var structpar__nvm__head__obj__t =
[
    [ "crc", "structpar__nvm__head__obj__t.html#ac5381ac5a59cc6e3c42d1ae94583889f", null ],
    [ "obj_nb", "structpar__nvm__head__obj__t.html#a5a5eb845cfde6290fad9272683d9e25c", null ],
    [ "sign", "structpar__nvm__head__obj__t.html#a52449a31e9d603cdb3df914434de0af4", null ]
];