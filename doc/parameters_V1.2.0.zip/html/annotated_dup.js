var annotated_dup =
[
    [ "par_cfg_t", "structpar__cfg__t.html", "structpar__cfg__t" ],
    [ "par_nvm_data_obj_t", "structpar__nvm__data__obj__t.html", "structpar__nvm__data__obj__t" ],
    [ "par_nvm_head_obj_t", "structpar__nvm__head__obj__t.html", "structpar__nvm__head__obj__t" ],
    [ "par_nvm_lut_t", "structpar__nvm__lut__t.html", "structpar__nvm__lut__t" ],
    [ "par_type_t", "unionpar__type__t.html", "unionpar__type__t" ]
];