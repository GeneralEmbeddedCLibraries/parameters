var group___p_a_r___n_v_m =
[
    [ "par_nvm_head_obj_t", "structpar__nvm__head__obj__t.html", [
      [ "crc", "structpar__nvm__head__obj__t.html#ac5381ac5a59cc6e3c42d1ae94583889f", null ],
      [ "obj_nb", "structpar__nvm__head__obj__t.html#a5a5eb845cfde6290fad9272683d9e25c", null ],
      [ "sign", "structpar__nvm__head__obj__t.html#a52449a31e9d603cdb3df914434de0af4", null ]
    ] ],
    [ "par_nvm_data_obj_t", "structpar__nvm__data__obj__t.html", [
      [ "crc", "structpar__nvm__data__obj__t.html#ac1661764e816a367004b379ba719b953", null ],
      [ "data", "structpar__nvm__data__obj__t.html#abfaf7d70159fabe8deced4d67390a83e", null ],
      [ "id", "structpar__nvm__data__obj__t.html#a3d3b7673ec6fd5de7bc33391a5350f27", null ],
      [ "size", "structpar__nvm__data__obj__t.html#a995fc8c3b36a66102e8c616a0e4e3d21", null ]
    ] ],
    [ "par_nvm_lut_t", "structpar__nvm__lut__t.html", [
      [ "addr", "structpar__nvm__lut__t.html#a979830fab95ba158b83924d3da3bef56", null ],
      [ "id", "structpar__nvm__lut__t.html#a69ae7fb3de7977120dce375c9e211dd8", null ],
      [ "valid", "structpar__nvm__lut__t.html#ae8858c0ce010c9c35aef93e6d07f7a6e", null ]
    ] ],
    [ "PAR_NVM_CRC_SIZE", "group___p_a_r___n_v_m.html#ga54b56cc59baf9f1d7bc39fa3ed29c0f3", null ],
    [ "PAR_NVM_FIRST_DATA_OBJ_ADDR", "group___p_a_r___n_v_m.html#gabe35de99a412c8108ca05891ae5b99be", null ],
    [ "PAR_NVM_HASH_SIZE", "group___p_a_r___n_v_m.html#ga31896428895922f50d20f15c0206fb6f", null ],
    [ "PAR_NVM_HEAD_ADDR", "group___p_a_r___n_v_m.html#gae3770e3d9d36e7ed912cbc2a140a9c75", null ],
    [ "PAR_NVM_HEAD_CRC_ADDR", "group___p_a_r___n_v_m.html#ga6250ced6cfe0bb204b3cce7b4934a4ee", null ],
    [ "PAR_NVM_HEAD_HASH_ADDR", "group___p_a_r___n_v_m.html#ga5d269731c62158746a3cdb1c1d55c2cd", null ],
    [ "PAR_NVM_HEAD_NB_OF_OBJ_ADDR", "group___p_a_r___n_v_m.html#ga68ee68843a3dbbc3e33a0463455913af", null ],
    [ "PAR_NVM_HEAD_SIGN_ADDR", "group___p_a_r___n_v_m.html#gaf661cf2f5df02aaa56da0a54c36bb7fd", null ],
    [ "PAR_NVM_NB_OF_OBJ_SIZE", "group___p_a_r___n_v_m.html#gaca2f4f6ab4d0bef1b7db0d4675c95abb", null ],
    [ "PAR_NVM_SIGN", "group___p_a_r___n_v_m.html#ga7262c9b0b128b44452e217352b82afc4", null ],
    [ "PAR_NVM_SIGN_SIZE", "group___p_a_r___n_v_m.html#gaf12daca1829321199dcef32da7591f08", null ],
    [ "par_nvm_init", "group___p_a_r___n_v_m.html#ga6edd0d2ef60beb2a0c755547fa1872d1", null ],
    [ "par_nvm_print_nvm_lut", "group___p_a_r___n_v_m.html#ga1844f5d925ad14f0bd7026c6160a8c14", null ],
    [ "par_nvm_write", "group___p_a_r___n_v_m.html#ga87355a65f364a4f9ec16fd889dc79c09", null ],
    [ "par_nvm_write_all", "group___p_a_r___n_v_m.html#ga600da4f6f0d52db3726a739429758f2e", null ],
    [ "g_par_nvm_data_obj_addr", "group___p_a_r___n_v_m.html#gafb1066f788f2115b861933b7667dd8be", null ]
];