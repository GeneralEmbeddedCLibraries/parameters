var group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s =
[
    [ "par_nvm_build_new_nvm_lut", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gab6ee605078c3bfbe050860033cd73ee8", null ],
    [ "par_nvm_calc_crc", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga2856d3948a259a7df8523ba1d56ff522", null ],
    [ "par_nvm_calc_obj_crc", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga109558ba8130f8b24fd7f4fb367f15c6", null ],
    [ "par_nvm_corrupt_signature", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga697686c6715a5964c1aac4e1a81e310e", null ],
    [ "par_nvm_get_nvm_lut_addr", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga00363ae211acc1bdf0d26ce469667634", null ],
    [ "par_nvm_get_per_par", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gaffbfec19547cada07adbad6b6a44a3c8", null ],
    [ "par_nvm_is_in_nvm_lut", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga5eed04bd3b52680349c945df4bd20589", null ],
    [ "par_nvm_load_all", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gaff7a340659f87e08accef9e9035495e6", null ],
    [ "par_nvm_print_nvm_lut", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga1844f5d925ad14f0bd7026c6160a8c14", null ],
    [ "par_nvm_read_header", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gac9d9e4ddaeaf885aa33e6352ac82f45e", null ],
    [ "par_nvm_reset_all", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gae3e79af03d14f3672083cc8e5d9212e0", null ],
    [ "par_nvm_validate_header", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#ga2dc86c8573e0c8fc97bd22daeb74eb57", null ],
    [ "par_nvm_write_header", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gadd4a589e6d58bd0d6b1d64fcfc47d24c", null ],
    [ "par_nvm_write_signature", "group___k_e_r_n_e_l___p_a_r___n_v_m___f_u_n_c_t_i_o_n_s.html#gab974ab946c1c795b9dd17d6e9930ccd2", null ]
];