var structpar__nvm__data__obj__t =
[
    [ "crc", "structpar__nvm__data__obj__t.html#ac1661764e816a367004b379ba719b953", null ],
    [ "data", "structpar__nvm__data__obj__t.html#abfaf7d70159fabe8deced4d67390a83e", null ],
    [ "id", "structpar__nvm__data__obj__t.html#a3d3b7673ec6fd5de7bc33391a5350f27", null ],
    [ "size", "structpar__nvm__data__obj__t.html#a995fc8c3b36a66102e8c616a0e4e3d21", null ]
];